# app/models/url.py
from pydantic import BaseModel

class URLBase(BaseModel):
    original_url: str
    short_url: str

# Use this for creating the URL entry (request model)
class URLCreate(BaseModel):
    original_url: str

# Use this for returning the URL entry (response model)
class URLResponse(URLBase):
    class Config:
        orm_mode = True
