from fastapi import FastAPI, HTTPException
from app.api.routes import router
from app.db.database import engine, Base, SessionLocal
from app.models.url import URLCreate, URLResponse
from app.models import url  # Import your models
from app.db.database import Base
from app.models.url import URLBase, URLCreate, URLResponse

app = FastAPI()

# Create the database tables
@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

app.include_router(router, prefix="/api")

@app.post("/urls/", response_model=URLResponse)
def create_url(url: URLCreate):
    db = SessionLocal()
    db_url = URL(original_url=url.original_url, short_url="short_link")  # Replace "short_link" with actual logic
    db.add(db_url)
    db.commit()
    db.refresh(db_url)
    return db_url

@app.get("/")
async def read_root():
    return {"message": "Welcome to the URL Shortener API"}
